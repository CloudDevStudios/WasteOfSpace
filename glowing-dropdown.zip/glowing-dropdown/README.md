# Glowing Dropdown 

A Pen created on CodePen.io. Original URL: [https://codepen.io/LukyVj/pen/ZEMrgMr](https://codepen.io/LukyVj/pen/ZEMrgMr).

Inspired by this tweet of @UI8 https://twitter.com/ui8/status/1633368459319885825

Find my twitter thread: https://twitter.com/LukyVJ/status/1635693759714164736?s=20


Chrome: ✅
Safari: 🟧
Firefox: 