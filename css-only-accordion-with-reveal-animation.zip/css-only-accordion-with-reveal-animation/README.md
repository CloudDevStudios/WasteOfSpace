# CSS-only Accordion with Reveal Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/ShadowShahriar/pen/LYgeNLB](https://codepen.io/ShadowShahriar/pen/LYgeNLB).

This CodePen demonstrates how we can animate the opening and closing states of an accordion with fancy reveal animation using only CSS. This concept is suitable for creating **FAQ sections**, **Table of Contents**, and more.